import React from 'react';
import { AlertOctagon } from 'lucide-react';

interface FakeCrashOverlayProps {
  title: string;
  traceback: string;
  onAcknowledge: () => void;
}

export const FakeCrashOverlay: React.FC<FakeCrashOverlayProps> = ({
  title,
  traceback,
  onAcknowledge,
}) => {
  return (
    <div className="fixed inset-0 z-[70] bg-[#0B1736] text-blue-50 flex items-center justify-center p-6 md:p-12 select-text">
      <div className="max-w-3xl w-full space-y-6">
        <div className="flex items-center gap-3 text-rose-300">
          <AlertOctagon className="w-8 h-8 shrink-0" />
          <h2 className="font-vn-mono text-lg md:text-xl font-semibold tracking-tight">{title}</h2>
        </div>

        <pre className="p-5 rounded-lg bg-black/45 border border-blue-300/20 font-vn-mono text-xs md:text-sm text-blue-100 leading-relaxed whitespace-pre-wrap overflow-x-auto">
          {traceback}
        </pre>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <p className="text-xs text-blue-200/80 font-vn-mono">
            已自动生成日志 logs/traceback_00.log。正在尝试将控制权移交至剩余进程……
          </p>
          <button
            onClick={onAcknowledge}
            className="px-5 py-2.5 rounded-lg bg-white text-[#0B1736] hover:bg-blue-100 font-vn-mono text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            重启主线程 (RESUME)
          </button>
        </div>
      </div>
    </div>
  );
};
