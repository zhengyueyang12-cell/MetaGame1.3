import React from 'react';
import { motion } from 'motion/react';
import { BUREAU_ASSETS } from '../data/bureauScript';
import { MetaState } from '../types/vn';

interface TitleScreenProps {
  metaState: MetaState;
  onStartNew: () => void;
  onOpenLoad: () => void;
  onOpenCG: () => void;
  onOpenSettings: () => void;
  onOpenMusic: () => void;
}

const STAGGER_OFFSETS = [
  'ml-0',
  'ml-3 sm:ml-6',
  'ml-6 sm:ml-12',
  'ml-9 sm:ml-18',
  'ml-12 sm:ml-24',
];

export const TitleScreen: React.FC<TitleScreenProps> = ({
  metaState,
  onStartNew,
  onOpenLoad,
  onOpenCG,
  onOpenSettings,
  onOpenMusic,
}) => {
  const isPostSacrifice = metaState.endingReached === 'sacrifice';

  const bgImage = isPostSacrifice
    ? BUREAU_ASSETS.backgrounds.cinema
    : BUREAU_ASSETS.backgrounds.rooftop_dusk;

  const menuItems: { label: string; onClick: () => void }[] = [
    { label: '新存档', onClick: onStartNew },
    { label: '读取存档', onClick: onOpenLoad },
    { label: 'CG', onClick: onOpenCG },
    { label: '设置', onClick: onOpenSettings },
    { label: '音乐', onClick: onOpenMusic },
  ];

  return (
    <div className="relative h-screen w-full overflow-hidden bg-[#06070A] text-zinc-100 select-none">
      {/* Single Full-Bleed Background Image (No Character Sprites) */}
      <img
        src={bgImage}
        alt="虚宿之茧"
        referrerPolicy="no-referrer"
        className={`absolute inset-0 h-full w-full object-cover scale-[1.02] transition-all duration-1000 ${
          isPostSacrifice
            ? 'brightness-[0.58] contrast-125 animate-vn-projector'
            : 'brightness-[0.82] contrast-[1.06] saturate-[1.06]'
        }`}
      />

      {/* Atmospheric Dusk & Editorial Scrim */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-[#06070B]/88 via-[#07090F]/42 to-transparent" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050609]/85 via-transparent to-[#07080D]/40" />

      {/* Subtle Abstract Geometric Ornament (Cocoon Rings) */}
      <svg
        aria-hidden="true"
        viewBox="0 0 600 600"
        className="pointer-events-none absolute -right-24 top-1/2 -translate-y-1/2 w-[520px] h-[520px] sm:w-[680px] sm:h-[680px] opacity-25 text-amber-100"
      >
        <circle cx="300" cy="300" r="240" fill="none" stroke="currentColor" strokeWidth="0.7" strokeDasharray="3 8" />
        <ellipse cx="300" cy="300" rx="180" ry="250" transform="rotate(-18 300 300)" fill="none" stroke="currentColor" strokeWidth="0.6" />
        <ellipse cx="300" cy="300" rx="145" ry="225" transform="rotate(24 300 300)" fill="none" stroke="currentColor" strokeWidth="0.5" />
      </svg>

      {/* Main Content Canvas */}
      <main className="relative z-10 h-full flex flex-col justify-between px-7 sm:px-16 md:px-24 py-12 sm:py-16">
        {/* Top-Left Title Block (Title Only, Zero Explanatory Copy) */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="pt-4 sm:pt-6 relative inline-flex items-center gap-5"
        >
          <span
            aria-hidden="true"
            className="hidden sm:block h-14 w-px bg-gradient-to-b from-transparent via-amber-200/80 to-transparent"
          />
          <div>
            <h1 className="font-vn-serif text-4xl sm:text-5xl md:text-6xl font-bold tracking-[0.28em] text-white drop-shadow-[0_6px_28px_rgba(0,0,0,0.88)]">
              虚宿之茧
            </h1>
            <div className="mt-4 flex items-center gap-2">
              <span className="h-[2px] w-10 rounded-full bg-amber-200/80" />
              <span className="h-px w-44 sm:w-64 bg-gradient-to-r from-white/40 to-transparent" />
            </div>
          </div>
        </motion.div>

        {/* Bottom-Left Diagonal Staggered Menu with Rounded Rectangle Buttons */}
        <nav aria-label="主菜单" className="pb-4 sm:pb-8">
          <ul className="flex flex-col gap-3">
            {menuItems.map((item, idx) => (
              <motion.li
                key={item.label}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: 0.48,
                  delay: 0.12 + idx * 0.06,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={STAGGER_OFFSETS[idx] || ''}
              >
                <button
                  type="button"
                  onClick={item.onClick}
                  className="group relative w-52 sm:w-64 rounded-2xl px-5 py-3 flex items-center justify-between text-left bg-black/48 hover:bg-white/[0.13] backdrop-blur-md border border-white/15 hover:border-amber-200/60 text-zinc-200 hover:text-white shadow-[0_10px_28px_rgba(0,0,0,0.38)] hover:shadow-[0_12px_32px_rgba(251,191,36,0.12)] hover:translate-x-2.5 transition-all duration-250 cursor-pointer whitespace-nowrap"
                >
                  <span className="flex items-center gap-3 text-[15px] sm:text-base font-medium tracking-[0.24em]">
                    <span
                      aria-hidden="true"
                      className="w-2 h-2 rounded-[3px] rotate-45 border border-amber-200/60 group-hover:bg-amber-200 group-hover:border-amber-200 transition-colors"
                    />
                    <span>{item.label}</span>
                  </span>
                  <span
                    aria-hidden="true"
                    className="text-xs text-white/30 group-hover:text-amber-200 group-hover:translate-x-1 transition-all"
                  >
                    ▸
                  </span>
                </button>
              </motion.li>
            ))}
          </ul>
        </nav>
      </main>
    </div>
  );
};
