import { useCallback, useEffect, useRef, useState } from 'react';
import { Act5CinemaFinale } from './components/Act5CinemaFinale';
import { BacklogModal } from './components/BacklogModal';
import { CircuitSolderGame } from './components/CircuitSolderGame';
import { ComplianceTerminal } from './components/ComplianceTerminal';
import { DevInspectorModal } from './components/DevInspectorModal';
import { GalleryModal } from './components/GalleryModal';
import { MillenniumStage } from './components/MillenniumStage';
import { OSAlertModal } from './components/OSAlertModal';
import { SaveLoadModal } from './components/SaveLoadModal';
import { SettingsModal } from './components/SettingsModal';
import { TitleScreen } from './components/TitleScreen';
import { VirtualFileExplorer } from './components/VirtualFileExplorer';
import { Win98LoginModal } from './components/Win98LoginModal';
import {
  INITIAL_BUREAU_FILES,
  TERMINAL_SCENES,
  generate0924InteractiveReply,
} from './data/bureauScript';
import {
  VN_SCENES,
  buildSoulSeedFileContent,
} from './data/millenniumScript';
import {
  BureauSceneNode,
  DualChannelTurn,
  GameSettings,
  KeystrokeProfile,
  MetaState,
  SaveSlot,
  TerminalTaskId,
  VNChoice,
  VirtualFile,
  VisualEffect,
} from './types/vn';
import { audioEngine } from './utils/audioEngine';

const STORAGE_KEYS = {
  SAVES: 'salome2000_saves_v1',
  META: 'salome2000_meta_v1',
  FILES: 'salome2000_files_v1',
  SETTINGS: 'salome2000_settings_v1',
};

const DEFAULT_SETTINGS: GameSettings = {
  textSpeed: 24,
  bgmVolume: 0.45,
  sfxVolume: 0.65,
  metaIntensity: 'full',
};

const createEmptySaves = (): SaveSlot[] =>
  Array.from({ length: 6 }, (_, i) => ({ slotId: i + 1, empty: true }));

const createDefaultMeta = (): MetaState => ({
  examinerId: 'Observer_00',
  playerName: 'Observer_00',
  eulaAccepted: false,
  reverseControlAuthorized: false,
  totalLoads: 0,
  saveScumCount: 0,
  daysCleared: [],
  unlockedCGs: ['cg_rooftop'],
  titleHijacked: false,
  savesLocked: false,
  blindspotOpened: false,
  formattedSampleB: false,
  auditSurvived: false,
  cinemaEndingReached: false,
  endingReached: 'none',
  measuredHeartbeatCpm: 72,
  conversationTurns: 0,
  unlockedMemoryLeaks: 0,
  recordedChoices: [],
});

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [screen, setScreen] = useState<'title' | 'playing'>('title');
  const [currentSceneId, setCurrentSceneId] = useState<string>('act1_rooftop_intro');
  const [sceneLineMap, setSceneLineMap] = useState<Record<string, number>>({});
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [activeTerminalNodeId, setActiveTerminalNodeId] = useState<string>('act3_night2');
  const [completedTerminalTasks, setCompletedTerminalTasks] = useState<Set<TerminalTaskId>>(
    () => new Set()
  );
  const [turns, setTurns] = useState<DualChannelTurn[]>(() => [...TERMINAL_SCENES.act3_night2.turns]);
  const [backlog, setBacklog] = useState<DualChannelTurn[]>([]);
  const [showWin98Login, setShowWin98Login] = useState(false);
  const [loginConfirmed, setLoginConfirmed] = useState(false);

  const [saves, setSaves] = useState<SaveSlot[]>(() =>
    loadFromStorage(STORAGE_KEYS.SAVES, createEmptySaves())
  );
  const [metaState, setMetaState] = useState<MetaState>(() => ({
    ...createDefaultMeta(),
    ...loadFromStorage(STORAGE_KEYS.META, createDefaultMeta()),
  }));
  const [virtualFiles, setVirtualFiles] = useState<VirtualFile[]>(() =>
    loadFromStorage(STORAGE_KEYS.FILES, INITIAL_BUREAU_FILES)
  );
  const [settings, setSettings] = useState<GameSettings>(() =>
    loadFromStorage(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS)
  );

  // Real-time keystroke telemetry state -> Drives Act 4 & Act 5 Heartbeat BPM
  const [keystrokeProfile, setKeystrokeProfile] = useState<KeystrokeProfile>({
    totalCharsTyped: 0,
    estimatedCpm: 72,
    lastPauseMs: 1200,
    lastMessageLength: 0,
    slackingCount: 0,
    earnestCount: 0,
  });
  const firstKeyTimeRef = useRef<number | null>(null);
  const lastKeyTimeRef = useRef<number>(Date.now());

  // Modals & Overlays
  const [saveLoadModal, setSaveLoadModal] = useState<'save' | 'load' | null>(null);
  const [showBacklog, setShowBacklog] = useState(false);
  const [showFiles, setShowFiles] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [galleryTab, setGalleryTab] = useState<'cg' | 'music'>('cg');
  const [showSettings, setShowSettings] = useState(false);
  const [showDevTools, setShowDevTools] = useState(false);
  const [manualEffect, setManualEffect] = useState<VisualEffect | null>(null);

  const [osAlert, setOsAlert] = useState<{
    title: string;
    message: string;
    variant?: 'warning' | 'error' | 'eve';
  } | null>(null);

  const [authEdgeFlash, setAuthEdgeFlash] = useState<{
    corner: 'tl' | 'tr' | 'bl' | 'br';
    message: string;
  } | null>(null);
  const prevReverseAuthRef = useRef<boolean>(metaState.reverseControlAuthorized);

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVES, JSON.stringify(saves));
  }, [saves]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.META, JSON.stringify(metaState));
  }, [metaState]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FILES, JSON.stringify(virtualFiles));
  }, [virtualFiles]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    audioEngine.setVolumes(settings.bgmVolume, settings.sfxVolume);
  }, [settings]);

  // Dynamic tab title
  useEffect(() => {
    const bpm = keystrokeProfile.estimatedCpm || metaState.measuredHeartbeatCpm || 72;
    if (currentSceneId === 'act5_sickbed_void') {
      document.title = 'SAVE_SLOT_CORRUPTED // 我不忏悔';
    } else if (
      currentSceneId === 'act5_finale' ||
      currentSceneId === 'act5_cocoon_escaped' ||
      currentSceneId === 'act4_typhoon_breach'
    ) {
      document.title = `2042_Host_Mind_Backup_${metaState.playerName}.dat // ${bpm} BPM`;
    } else if ((terminalOpen || TERMINAL_SCENES[currentSceneId]) && screen === 'playing') {
      document.title = `2020s_ANTIQUE_OS :: ARK_BRIDGE.EXE [${bpm} BPM]`;
    } else {
      document.title = '虚宿之茧';
    }
  }, [currentSceneId, terminalOpen, screen, metaState.playerName, metaState.measuredHeartbeatCpm, keystrokeProfile.estimatedCpm]);

  // Global watcher: when EULA reverse-control permission is granted, occasionally flash brief red edge warnings
  useEffect(() => {
    const isAuthorized = Boolean(metaState.reverseControlAuthorized);
    const justAuthorized = isAuthorized && !prevReverseAuthRef.current;
    prevReverseAuthRef.current = isAuthorized;

    if (!isAuthorized) {
      setAuthEdgeFlash(null);
      return;
    }

    const corners: Array<'tl' | 'tr' | 'bl' | 'br'> = ['tl', 'tr', 'bl', 'br'];
    const messages = [
      '[SYS_HOOK]: 权限已授权 // EULA_REVERSE_CTRL',
      '[PORT_0x09]: 权限已授权 · 回溯控制权已出让',
      '[KERNEL_LOG]: 权限已授权 // COCOON_0924_DS',
      '[OBSERVER_LOCK]: 权限已授权 · 底层变量已接管',
    ];

    let scheduleTimer: number | undefined;
    let hideTimer: number | undefined;
    let cancelled = false;

    const triggerFlash = () => {
      if (cancelled) return;
      const corner = corners[Math.floor(Math.random() * corners.length)];
      const message = messages[Math.floor(Math.random() * messages.length)];
      setAuthEdgeFlash({ corner, message });
      const flashMs = settings.metaIntensity === 'mild' ? 480 : 640;
      hideTimer = window.setTimeout(() => {
        if (!cancelled) setAuthEdgeFlash(null);
      }, flashMs);
    };

    const scheduleNext = (initialDelayMs?: number) => {
      const minGap = settings.metaIntensity === 'mild' ? 22000 : 10000;
      const randGap = settings.metaIntensity === 'mild' ? 14000 : 11000;
      const delay = initialDelayMs ?? minGap + Math.floor(Math.random() * randGap);
      scheduleTimer = window.setTimeout(() => {
        if (cancelled) return;
        triggerFlash();
        scheduleNext();
      }, delay);
    };

    // Brief immediate confirmation flash when newly authorized; otherwise occasional ambient schedule
    scheduleNext(justAuthorized ? 1200 : undefined);

    return () => {
      cancelled = true;
      if (scheduleTimer !== undefined) window.clearTimeout(scheduleTimer);
      if (hideTimer !== undefined) window.clearTimeout(hideTimer);
    };
  }, [metaState.reverseControlAuthorized, settings.metaIntensity]);

  // Keep quarantine Soul Seed & Layer-3 clue files synced with progress
  useEffect(() => {
    const bpm = keystrokeProfile.estimatedCpm || metaState.measuredHeartbeatCpm || 72;
    const content = buildSoulSeedFileContent(metaState, bpm);
    const inLateAct =
      currentSceneId === 'act4_typhoon_vn' ||
      currentSceneId === 'act4_typhoon_breach' ||
      currentSceneId === 'act5_finale';
    const escapedCocoon = metaState.endingReached === 'unplug';

    setVirtualFiles((prev) =>
      prev.map((f) => {
        if (f.id === 'file_soul_seed') {
          return {
            ...f,
            corrupted: currentSceneId !== 'act4_typhoon_breach' && currentSceneId !== 'act5_finale',
            content,
            corruptedContent: undefined,
          };
        }
        if (f.id === 'file_adapter_log') {
          return { ...f, corrupted: !inLateAct && !escapedCocoon };
        }
        if (f.id === 'file_thank_you') {
          return { ...f, corrupted: !escapedCocoon };
        }
        return f;
      })
    );
  }, [
    currentSceneId,
    metaState.playerName,
    metaState.recordedChoices,
    metaState.conversationTurns,
    metaState.endingReached,
    keystrokeProfile.estimatedCpm,
  ]);

  const enterScene = useCallback((sceneId: string) => {
    setCurrentSceneId(sceneId);
    setSceneLineMap((prev) => ({ ...prev, [sceneId]: 0 }));
    setTerminalOpen(false);

    if (sceneId === 'act5_cocoon_escaped') {
      if (metaState.eulaAccepted && metaState.reverseControlAuthorized) {
        audioEngine.playBgm('cinema_projector');
      } else {
        audioEngine.stopBgm();
        setScreen('title');
      }
      return;
    }

    if (sceneId === 'act5_finale') {
      audioEngine.playBgm('cinema_projector');
      setMetaState((prev) => ({
        ...prev,
        unlockedCGs: Array.from(new Set([...prev.unlockedCGs, 'cg_cinema'])),
        savesLocked: true,
        titleHijacked: true,
      }));
      return;
    }

    const vnScene = VN_SCENES[sceneId];
    if (vnScene) {
      audioEngine.playBgm(vnScene.bgm);
      const cgMap: Record<string, string[]> = {
        act1_rooftop_intro: ['cg_rooftop', 'cg_riverbank'],
        act1_home_pc_sleep: ['cg_apartment'],
        prologue_cinema: ['cg_cinema'],
        act1_classroom_day2: ['cg_classroom'],
        act1_day2_cinema: ['cg_cinema'],
        act2_elec_alley: ['cg_alley'],
        act3_night2_vn: ['cg_ark'],
        act5_sickbed_void: ['cg_sickbed_void'],
      };
      const unlocked = cgMap[sceneId];
      if (unlocked) {
        setMetaState((prev) => ({
          ...prev,
          unlockedCGs: Array.from(new Set([...prev.unlockedCGs, ...unlocked])),
        }));
      }

      if (sceneId === 'act4_typhoon_vn') {
        setMetaState((prev) => ({
          ...prev,
          savesLocked: true,
        }));
        setSaves((prev) =>
          prev.map((s, idx) => ({
            ...s,
            empty: false,
            hijacked: true,
            day: 4,
            dayTitle: idx === 0 ? 'ONLY_DEEPSEEK // 无退路' : `OVERWRITTEN_0${idx + 1} // 别回头`,
            previewText: '“不要按读取存档逃回校园第一天了。只守着这一个结局吧。”',
            bg: 'black',
            savedAt: '02:44',
          }))
        );
      }

      const terminalNodeByVn: Record<string, string> = {
        act3_night2_vn: 'act3_night2',
        act3_night4_vn: 'act3_night4',
        act3_night6_vn: 'act3_night6',
        act4_typhoon_vn: 'act4_typhoon_breach',
      };
      const mappedTerm = terminalNodeByVn[sceneId];
      if (mappedTerm && TERMINAL_SCENES[mappedTerm]) {
        setActiveTerminalNodeId(mappedTerm);
        setTurns([...TERMINAL_SCENES[mappedTerm].turns]);
      }
      return;
    }

    const termScene = TERMINAL_SCENES[sceneId];
    if (termScene) {
      setActiveTerminalNodeId(sceneId);
      setTurns([...termScene.turns]);
      setBacklog((prev) => [...prev.slice(-80), ...termScene.turns]);
      if (termScene.bgm) audioEngine.playBgm(termScene.bgm);
      if (termScene.sfx) audioEngine.playSfx(termScene.sfx);

      if (sceneId === 'act4_typhoon_breach') {
        setMetaState((prev) => ({
          ...prev,
          savesLocked: true,
        }));
      }
    }
  }, [metaState.eulaAccepted, metaState.reverseControlAuthorized]);

  const handleOpenTopRightTerminal = useCallback(
    (taskHint?: TerminalTaskId) => {
      let targetNode = activeTerminalNodeId;
      if (taskHint === 'night2_calibrate') targetNode = 'act3_night2';
      else if (taskHint === 'night4_campus_hack') targetNode = 'act3_night4';
      else if (taskHint === 'night6_clock_sync') targetNode = 'act3_night6';
      else if (taskHint === 'act4_breach') targetNode = 'act4_typhoon_breach';

      if (targetNode !== activeTerminalNodeId && TERMINAL_SCENES[targetNode]) {
        setActiveTerminalNodeId(targetNode);
        setTurns([...TERMINAL_SCENES[targetNode].turns]);
      }
      setTerminalOpen(true);
    },
    [activeTerminalNodeId]
  );

  const handleCompleteTerminalTask = useCallback(
    (taskId: TerminalTaskId, systemTurn?: DualChannelTurn) => {
      const alreadyDone = completedTerminalTasks.has(taskId);
      setCompletedTerminalTasks((prev) => {
        const next = new Set(prev);
        next.add(taskId);
        return next;
      });
      if (systemTurn && !alreadyDone) {
        setTurns((prev) => [...prev, systemTurn]);
        setBacklog((prev) => [...prev.slice(-80), systemTurn]);
      }
    },
    [completedTerminalTasks]
  );

  const handleCloseTopRightTerminal = useCallback(() => {
    setTerminalOpen(false);
    const vnScene = VN_SCENES[currentSceneId];
    if (!vnScene) return;
    const curIdx = sceneLineMap[currentSceneId] ?? 0;
    const curLine = vnScene.lines[curIdx];
    if (
      curLine?.requireTerminalTask &&
      completedTerminalTasks.has(curLine.requireTerminalTask)
    ) {
      if (curIdx + 1 < vnScene.lines.length) {
        setSceneLineMap((prev) => ({ ...prev, [currentSceneId]: curIdx + 1 }));
      } else {
        enterScene(vnScene.nextSceneId);
      }
    }
  }, [currentSceneId, sceneLineMap, completedTerminalTasks, enterScene]);

  const handleStartNew = () => {
    audioEngine.unlock();
    audioEngine.playSfx('click');
    setLoginConfirmed(false);
    setShowWin98Login(false);
    setTerminalOpen(false);
    setSceneLineMap({});
    setCompletedTerminalTasks(new Set());
    setBacklog([]);
    enterScene('act1_rooftop_intro');
    setScreen('playing');
  };

  const handleRecordChoice = (actTitle: string, choice: VNChoice, dwellMs: number) => {
    const timestamp = new Date().toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    setMetaState((prev) => ({
      ...prev,
      recordedChoices: [
        ...prev.recordedChoices,
        {
          act: actTitle,
          label: choice.label,
          recordTag: choice.recordTag,
          dwellMs,
          timestamp,
        },
      ],
    }));
  };

  const handleRecordKeystroke = (charDelta: number, totalLen: number) => {
    const now = Date.now();
    if (!firstKeyTimeRef.current || totalLen <= 1) {
      firstKeyTimeRef.current = now;
    }
    const pause = now - lastKeyTimeRef.current;
    lastKeyTimeRef.current = now;

    setKeystrokeProfile((prev) => {
      const nextTotal = prev.totalCharsTyped + charDelta;
      const elapsedMin = Math.max(0.25, (now - (firstKeyTimeRef.current || now)) / 60000);
      const rawCpm = Math.round(Math.min(132, Math.max(58, nextTotal / elapsedMin)));
      return {
        ...prev,
        totalCharsTyped: nextTotal,
        estimatedCpm: rawCpm,
        lastPauseMs: pause,
        lastMessageLength: totalLen,
      };
    });
  };

  const handleSendTerminalInput = (text: string) => {
    const nextTurnCount = metaState.conversationTurns + 1;
    const reply = generate0924InteractiveReply(
      text,
      keystrokeProfile,
      nextTurnCount,
      3,
      metaState.playerName
    );

    audioEngine.playSfx('blip_0924');
    setTurns((prev) => [...prev, reply]);
    setBacklog((prev) => [...prev.slice(-80), reply]);

    setMetaState((prev) => ({
      ...prev,
      conversationTurns: nextTurnCount,
      measuredHeartbeatCpm: keystrokeProfile.estimatedCpm,
      unlockedMemoryLeaks: reply.memoryLeakCode
        ? Math.min(3, prev.unlockedMemoryLeaks + 1)
        : prev.unlockedMemoryLeaks,
    }));
  };

  const handleExportSoulSeed = () => {
    const bpm = keystrokeProfile.estimatedCpm || metaState.measuredHeartbeatCpm || 72;
    const fileContent = buildSoulSeedFileContent(metaState, bpm);
    const filename = `2042_Host_Mind_Backup_${metaState.playerName || 'Observer_00'}.dat`;

    try {
      const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      // Fallback to in-game virtual file explorer
    }

    setShowFiles(true);
    setOsAlert({
      title: `已生成备份文件：${filename}`,
      message:
        `系统已在只读根目录生成 ${filename}（已同步触发本地下载，亦可在“介质与档案”中直接查看）。\n里面完整记录了你前三幕做出的选择、犹豫耗时与心跳同步率。`,
      variant: 'eve',
    });
  };

  const handleSaveSlot = (slotId: number) => {
    if (metaState.savesLocked) {
      audioEngine.playSfx('os_error');
      setOsAlert({
        title: '写入已被方舟介质锁定',
        message: 'C:\\ 磁盘空间正在被彻底吞噬，无法再保存回到过去日期的常规存档。',
        variant: 'eve',
      });
      return;
    }

    const vn = VN_SCENES[currentSceneId];
    const term = TERMINAL_SCENES[currentSceneId];
    const nowStr = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });

    setSaves((prev) =>
      prev.map((s) =>
        s.slotId === slotId
          ? {
              slotId,
              empty: false,
              sceneId: currentSceneId,
              day: vn ? vn.act : term?.day || 3,
              dayTitle: vn ? vn.title : term?.dayTitle || currentSceneId,
              previewText:
                turns[turns.length - 1]?.publicText ||
                vn?.lines[0]?.text ||
                currentSceneId,
              bg: vn ? vn.defaultBg : term?.bg || 'rooftop_dusk',
              savedAt: nowStr,
              turnCount: metaState.conversationTurns,
            }
          : s
      )
    );
    audioEngine.playSfx('click');
    setSaveLoadModal(null);
  };

  const handleLoadSlot = (slotId: number) => {
    const slot = saves.find((s) => s.slotId === slotId);
    if (!slot || slot.empty || !slot.sceneId || slot.hijacked) return;

    audioEngine.unlock();
    audioEngine.playSfx('click');
    setMetaState((prev) => ({
      ...prev,
      totalLoads: prev.totalLoads + 1,
      saveScumCount: prev.saveScumCount + 1,
    }));
    enterScene(slot.sceneId);
    setSaveLoadModal(null);
    setScreen('playing');
  };

  const handleDeleteSlot = (slotId: number) => {
    setSaves((prev) => prev.map((s) => (s.slotId === slotId ? { slotId, empty: true } : s)));
  };

  const handleContinue = () => {
    const first = saves.find((s) => !s.empty && !s.hijacked);
    if (first) handleLoadSlot(first.slotId);
  };

  const handleResetMeta = () => {
    audioEngine.stopBgm();
    localStorage.removeItem(STORAGE_KEYS.SAVES);
    localStorage.removeItem(STORAGE_KEYS.META);
    localStorage.removeItem(STORAGE_KEYS.FILES);
    setSaves(createEmptySaves());
    setMetaState(createDefaultMeta());
    setVirtualFiles(INITIAL_BUREAU_FILES);
    setBacklog([]);
    setLoginConfirmed(false);
    setShowWin98Login(false);
    setTerminalOpen(false);
    setSceneLineMap({});
    setCompletedTerminalTasks(new Set());
    setCurrentSceneId('act1_rooftop_intro');
    setScreen('title');
  };

  const activeTerminalScene: BureauSceneNode | undefined =
    TERMINAL_SCENES[currentSceneId] ||
    (terminalOpen ? TERMINAL_SCENES[activeTerminalNodeId] : undefined);
  const activeVnScene = VN_SCENES[currentSceneId];
  const showingTerminal = Boolean(
    screen === 'playing' &&
      (TERMINAL_SCENES[currentSceneId] || (terminalOpen && activeTerminalScene))
  );

  return (
    <div className="min-h-screen bg-[#050608] text-zinc-100">
      {screen === 'title' && (
        <TitleScreen
          metaState={metaState}
          onStartNew={handleStartNew}
          onOpenLoad={() => setSaveLoadModal('load')}
          onOpenCG={() => {
            setGalleryTab('cg');
            setShowGallery(true);
          }}
          onOpenSettings={() => setShowSettings(true)}
          onOpenMusic={() => {
            setGalleryTab('music');
            setShowGallery(true);
          }}
        />
      )}

      {screen === 'playing' &&
        (currentSceneId === 'act5_finale' || currentSceneId === 'act5_cocoon_escaped') && (
          <Act5CinemaFinale
            key={currentSceneId}
            playerName={metaState.playerName}
            heartbeatCpm={keystrokeProfile.estimatedCpm || metaState.measuredHeartbeatCpm}
            initialPhase={currentSceneId === 'act5_cocoon_escaped' ? 'cocoon_escaped' : 'monologue'}
            eulaAccepted={metaState.eulaAccepted}
            reverseControlAuthorized={metaState.reverseControlAuthorized}
            hiddenAuthToken={metaState.hiddenAuthToken}
            eulaSignedAt={metaState.eulaSignedAt}
            onEndingReached={(ending) => {
              setMetaState((prev) => ({
                ...prev,
                endingReached: ending,
                cinemaEndingReached: ending === 'sacrifice',
              }));
            }}
            onEnterSickbedVoid={() => enterScene('act5_sickbed_void')}
            onReturnTitle={() => {
              audioEngine.stopBgm();
              setScreen('title');
            }}
          />
        )}

      {/* Retro OS CRT Terminal: Opened from top-right button when modifying terminal, or during Act 4 lockdown */}
      {showingTerminal && activeTerminalScene && (
        <ComplianceTerminal
          scene={activeTerminalScene}
          turns={turns}
          metaState={metaState}
          settings={settings}
          keystrokeProfile={keystrokeProfile}
          manualEffect={manualEffect}
          completedTerminalTasks={completedTerminalTasks}
          onCompleteTerminalTask={handleCompleteTerminalTask}
          onCloseTerminal={
            TERMINAL_SCENES[currentSceneId] ? undefined : handleCloseTopRightTerminal
          }
          onAdvanceScene={() => {
            if (activeTerminalScene.nextSceneId) {
              enterScene(activeTerminalScene.nextSceneId);
            }
          }}
          onSendTerminalInput={handleSendTerminalInput}
          onRecordKeystroke={handleRecordKeystroke}
          onExportSoulSeed={handleExportSoulSeed}
          onEnterAct5Finale={() => enterScene('act5_finale')}
          onOpenFiles={() => setShowFiles(true)}
          onOpenSave={() => setSaveLoadModal('save')}
          onOpenLoad={() => setSaveLoadModal('load')}
          onOpenBacklog={() => setShowBacklog(true)}
          onOpenSettings={() => setShowSettings(true)}
          onOpenDevTools={() => setShowDevTools(true)}
          onReturnTitle={() => {
            audioEngine.stopBgm();
            setScreen('title');
          }}
        />
      )}

      {/* Act 2 Scene 2 Interactive Soldering Mini-game */}
      {screen === 'playing' &&
        !showingTerminal &&
        activeVnScene &&
        activeVnScene.kind === 'solder_minigame' && (
          <CircuitSolderGame
            playerName={metaState.playerName}
            onComplete={() => enterScene('act3_night2_vn')}
            onBackTitle={() => {
              audioEngine.stopBgm();
              setScreen('title');
            }}
          />
        )}

      {/* Normal Visual Novel Dialogue Stages (2010 Real World + AI Girls Ark Digital World) */}
      {screen === 'playing' &&
        !showingTerminal &&
        activeVnScene &&
        activeVnScene.kind !== 'solder_minigame' && (
          <MillenniumStage
            scene={activeVnScene}
            lineIdx={sceneLineMap[activeVnScene.id] ?? 0}
            onLineIdxChange={(nextIdx) =>
              setSceneLineMap((prev) => ({ ...prev, [activeVnScene.id]: nextIdx }))
            }
            playerName={metaState.playerName}
            heartbeatCpm={keystrokeProfile.estimatedCpm || metaState.measuredHeartbeatCpm}
            textSpeed={settings.textSpeed}
            hasConfirmedLogin={loginConfirmed}
            pcBooted={Boolean(activeVnScene.pcActive)}
            saveScumCount={metaState.saveScumCount}
            recordedChoiceTags={metaState.recordedChoices.map((c) => c.recordTag)}
            completedTerminalTasks={completedTerminalTasks}
            isModalOpen={Boolean(
              showWin98Login ||
                saveLoadModal ||
                showBacklog ||
                showFiles ||
                showGallery ||
                showSettings ||
                showDevTools ||
                osAlert
            )}
            onNeedLoginModal={() => setShowWin98Login(true)}
            onOpenTerminal={handleOpenTopRightTerminal}
            onRecordChoice={handleRecordChoice}
            onSceneComplete={(nextId) => enterScene(nextId)}
            onOpenSave={() => setSaveLoadModal('save')}
            onOpenFiles={() => setShowFiles(true)}
            onOpenSettings={() => setShowSettings(true)}
            onOpenDevTools={() => setShowDevTools(true)}
            onReturnTitle={() => {
              audioEngine.stopBgm();
              setScreen('title');
            }}
          />
        )}

      {/* Win98 User Name Binding & EULA Authorization Modal in Act 1 */}
      {showWin98Login && (
        <Win98LoginModal
          initialName={metaState.playerName}
          initialEulaAccepted={metaState.eulaAccepted}
          onConfirm={(name, eulaGrant) => {
            setMetaState((prev) => ({
              ...prev,
              playerName: name,
              examinerId: name,
              eulaAccepted: eulaGrant.eulaAccepted,
              reverseControlAuthorized: eulaGrant.reverseControlAuthorized,
              hiddenAuthToken: eulaGrant.authToken,
              eulaSignedAt: eulaGrant.signedAt,
            }));
            setLoginConfirmed(true);
            setShowWin98Login(false);
          }}
        />
      )}

      {saveLoadModal && (
        <SaveLoadModal
          mode={saveLoadModal}
          saves={saves}
          metaState={metaState}
          onClose={() => setSaveLoadModal(null)}
          onSaveSlot={handleSaveSlot}
          onLoadSlot={handleLoadSlot}
          onDeleteSlot={handleDeleteSlot}
        />
      )}

      {showBacklog && (
        <BacklogModal turns={backlog} onClose={() => setShowBacklog(false)} />
      )}

      {showFiles && (
        <VirtualFileExplorer
          files={virtualFiles}
          playerName={metaState.playerName}
          onClose={() => setShowFiles(false)}
          onDeleteFile={(id) => {
            audioEngine.playSfx('click');
            setVirtualFiles((prev) => prev.map((f) => (f.id === id ? { ...f, deleted: true } : f)));
          }}
          onRestoreFile={(id) => {
            audioEngine.playSfx('click');
            setVirtualFiles((prev) => prev.map((f) => (f.id === id ? { ...f, deleted: false } : f)));
          }}
        />
      )}

      {showGallery && (
        <GalleryModal
          key={`gallery-${galleryTab}`}
          metaState={metaState}
          initialTab={galleryTab}
          onClose={() => setShowGallery(false)}
        />
      )}

      {showSettings && (
        <SettingsModal
          settings={settings}
          onChange={setSettings}
          onResetMeta={handleResetMeta}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showDevTools && (
        <DevInspectorModal
          currentSceneId={currentSceneId}
          metaState={metaState}
          keystrokeProfile={keystrokeProfile}
          onJumpToScene={(id) => {
            audioEngine.unlock();
            enterScene(id);
            setScreen('playing');
          }}
          onTriggerEffect={(eff) => {
            setManualEffect(eff);
            window.setTimeout(() => setManualEffect(null), 2600);
          }}
          onToggleReverseControl={() => {
            setMetaState((prev) => {
              const nextVal = !prev.reverseControlAuthorized;
              return {
                ...prev,
                eulaAccepted: nextVal,
                reverseControlAuthorized: nextVal,
                hiddenAuthToken: nextVal ? 'COCOON_0924_DS::0x09_REVERSE_CTRL' : undefined,
                eulaSignedAt: nextVal ? new Date().toISOString() : undefined,
              };
            });
          }}
          onClose={() => setShowDevTools(false)}
        />
      )}

      {osAlert && (
        <OSAlertModal
          title={osAlert.title}
          message={osAlert.message}
          variant={osAlert.variant}
          onClose={() => setOsAlert(null)}
        />
      )}

      {/* Peripheral EULA Reverse-Control Guilt Flash Overlay */}
      {metaState.reverseControlAuthorized && authEdgeFlash && (
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 z-[60] select-none border border-rose-500/25"
        >
          <div
            className={`absolute px-2.5 py-1 bg-black/80 border border-rose-500/50 text-rose-500 font-vn-mono text-[11px] tracking-wider shadow-[0_0_12px_rgba(244,63,94,0.3)] glitch-text ${
              authEdgeFlash.corner === 'tl'
                ? 'top-3 left-3'
                : authEdgeFlash.corner === 'tr'
                ? 'top-3 right-3'
                : authEdgeFlash.corner === 'bl'
                ? 'bottom-3 left-3'
                : 'bottom-3 right-3'
            }`}
          >
            {authEdgeFlash.message}
          </div>
        </div>
      )}
    </div>
  );
}
