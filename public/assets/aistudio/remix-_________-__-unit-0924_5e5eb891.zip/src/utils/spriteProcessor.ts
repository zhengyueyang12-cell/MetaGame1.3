import { useEffect, useState } from 'react';

const spriteCache = new Map<string, string>();

/**
 * Flood-fills pure white outer backdrop from the 4 corners/edges of generated character portraits
 * into alpha=0 so character sprites composite cleanly over any VN background without erasing
 * inner white clothing (e.g. school uniform collars).
 */
export function useTransparentSprite(src: string): string {
  const [processed, setProcessed] = useState<string>(() => spriteCache.get(src) || src);

  useEffect(() => {
    if (spriteCache.has(src)) {
      setProcessed(spriteCache.get(src)!);
      return;
    }

    let cancelled = false;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        const w = img.naturalWidth || img.width;
        const h = img.naturalHeight || img.height;
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, w, h);
        const data = imageData.data;

        const isNearWhite = (idx: number) => {
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          return r >= 232 && g >= 232 && b >= 232;
        };

        const visited = new Uint8Array(w * h);
        const queue = new Int32Array(w * h);
        let head = 0;
        let tail = 0;

        const pushIfWhite = (x: number, y: number) => {
          const p = y * w + x;
          if (visited[p]) return;
          if (isNearWhite(p * 4)) {
            visited[p] = 1;
            queue[tail++] = p;
          }
        };

        // Seed from top, left, right edges (skip bottom edge in case uniform has white hem)
        for (let x = 0; x < w; x++) {
          pushIfWhite(x, 0);
        }
        for (let y = 0; y < h; y++) {
          pushIfWhite(0, y);
          pushIfWhite(w - 1, y);
        }

        while (head < tail) {
          const p = queue[head++];
          const x = p % w;
          const y = (p - x) / w;
          data[p * 4 + 3] = 0;

          if (x > 0) pushIfWhite(x - 1, y);
          if (x < w - 1) pushIfWhite(x + 1, y);
          if (y > 0) pushIfWhite(x, y - 1);
          if (y < h - 1) pushIfWhite(x, y + 1);
        }

        // Feather 1px boundary pixels slightly for smooth anti-aliased edges
        for (let y = 1; y < h - 1; y++) {
          for (let x = 1; x < w - 1; x++) {
            const p = y * w + x;
            if (visited[p]) continue;
            if (
              visited[p - 1] ||
              visited[p + 1] ||
              visited[p - w] ||
              visited[p + w]
            ) {
              const idx = p * 4;
              const lum = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
              if (lum > 205) {
                data[idx + 3] = Math.round(data[idx + 3] * 0.45);
              }
            }
          }
        }

        ctx.putImageData(imageData, 0, 0);
        const outUrl = canvas.toDataURL('image/png');
        spriteCache.set(src, outUrl);
        if (!cancelled) {
          setProcessed(outUrl);
        }
      } catch {
        // Fallback to raw image if canvas fails
      }
    };
    img.src = src;

    return () => {
      cancelled = true;
    };
  }, [src]);

  return processed;
}
